
-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `restaurant_id` int UNSIGNED NOT NULL,
  `comment` varchar(150) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `restaurant_id`, `comment`) VALUES
(1, 1, 2, 'Quán không sáng sủa nhưng thoáng mát.'),
(2, 2, 2, 'Món nào cũng ngon!'),
(3, 1, 2, 'Bún Thái ngon nhứt nách :))))');
