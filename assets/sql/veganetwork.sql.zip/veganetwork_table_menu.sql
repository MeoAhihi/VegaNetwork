
-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int UNSIGNED NOT NULL,
  `restaurant_id` int UNSIGNED NOT NULL,
  `dish_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `price` mediumint(8) UNSIGNED ZEROFILL NOT NULL,
  `type` enum('món nước','món khô','đồ uống') COLLATE utf8mb4_general_ci NOT NULL,
  `likes` int(10) UNSIGNED ZEROFILL NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `restaurant_id`, `dish_name`, `price`, `type`, `likes`) VALUES
(1, 2, 'Hủ tiếu Sa tế', 00025000, 'món nước', 0000000001),
(2, 2, 'Bún Thái', 00025000, 'món nước', 0000000001),
(3, 2, 'Cơm thập cẩm', 00025000, 'món khô', 0000000001),
(4, 2, 'Trà đá', 00000000, 'đồ uống', 0000000010),
(5, 2, 'Phở', 00025000, 'món nước', 0000000010),
(6, 2, 'Bánh canh', 00025000, 'món nước', 0000000010),
(7, 2, 'Mì Quảng', 00025000, 'món nước', 0000000023),
(8, 2, 'Hủ tiếu mì', 00025000, 'món nước', 0000000054),
(9, 2, 'Bún riêu', 00025000, 'món nước', 0000000010),
(10, 2, 'Bùn Huế', 00025000, 'món nước', 0000000010);
