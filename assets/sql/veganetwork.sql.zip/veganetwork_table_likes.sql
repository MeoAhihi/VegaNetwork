
-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `restaurant_id` int UNSIGNED NOT NULL,
  `uer_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`restaurant_id`, `uer_id`) VALUES
(2, 1),
(3, 1),
(10, 1),
(2, 2);
